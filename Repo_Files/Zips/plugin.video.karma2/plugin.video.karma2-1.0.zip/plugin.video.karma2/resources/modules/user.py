import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmthcm1hMg==')

name = b.b64decode('S2FybWEgMg==')

host = b.b64decode('aHR0cDovL2ZsYXdsZXNzLWlwdHYubmV0')

port = b.b64decode('NDU0NQ==')