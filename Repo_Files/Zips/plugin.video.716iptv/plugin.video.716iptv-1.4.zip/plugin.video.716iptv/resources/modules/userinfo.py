import base64

addon_name   = base64.b64decode('NzE2IElQVFY=')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLjcxNmlwdHY=')

host         = base64.b64decode('aHR0cDovLzcxNmlwdHYuZGRucy5uZXQ=')
port         = base64.b64decode('MjU0NjE=')